from django.apps import AppConfig


class LmsAppConfig(AppConfig):
    name = 'LMS_app'
